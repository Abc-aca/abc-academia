# ABC Academia Website
موقع ABC Academia - شريكك الأكاديمي في قطر

## 📁 ملفات الموقع

```
abc-academia-website/
├── index.html      # الصفحة الرئيسية
├── services.html   # صفحة الخدمات
├── faq.html        # صفحة الأسئلة الشائعة
├── contact.html    # صفحة التواصل
├── styles.css      # ملف التنسيقات
├── script.js       # ملف الجافاسكريبت
└── README.md       # هذا الملف
```

## 🚀 طريقة النشر على GitHub Pages (مجاني!)

### الخطوة 1: إنشاء حساب GitHub
1. اذهب إلى [github.com](https://github.com)
2. اضغط "Sign up" وأنشئ حساب جديد
3. فعّل حسابك عبر الإيميل

### الخطوة 2: إنشاء Repository جديد
1. بعد تسجيل الدخول، اضغط على زر "+" في أعلى الصفحة
2. اختر "New repository"
3. سمِّ الـ Repository: `abc-academia` (أو أي اسم تريده)
4. اجعله **Public**
5. اضغط "Create repository"

### الخطوة 3: رفع ملفات الموقع
1. في صفحة الـ Repository الجديد، اضغط "uploading an existing file"
2. اسحب جميع ملفات الموقع (index.html, services.html, faq.html, contact.html, styles.css, script.js)
3. اكتب رسالة مثل "Initial upload"
4. اضغط "Commit changes"

### الخطوة 4: تفعيل GitHub Pages
1. اذهب إلى "Settings" في الـ Repository
2. في القائمة الجانبية، اضغط "Pages"
3. تحت "Source"، اختر "Deploy from a branch"
4. اختر "main" branch و "/ (root)"
5. اضغط "Save"

### الخطوة 5: انتظر دقيقة أو دقيقتين
- موقعك سيكون متاحًا على:
  `https://[اسم-حسابك].github.io/abc-academia/`

---

## ⚠️ تعديلات مطلوبة قبل النشر

### 1. رقم الواتساب
ابحث عن `974XXXXXXXX` في جميع الملفات واستبدله برقمك الحقيقي:
- مثال: `97412345678`

### 2. روابط السوشيال ميديا
ابحث عن `href="#"` في أقسام السوشيال ميديا واستبدلها بروابطك:
- Instagram: `https://instagram.com/abc.academia`
- Snapchat: `https://snapchat.com/add/abcacademia`
- TikTok: `https://tiktok.com/@abc.academia`

### 3. الشعار (اختياري)
إذا كان لديك شعار:
1. احفظه باسم `logo.png` في نفس المجلد
2. استبدل الإيموجي 📚 في الكود بـ:
```html
<img src="logo.png" alt="ABC Academia" class="logo-img">
```

---

## 🎨 تخصيص الألوان

الألوان موجودة في بداية ملف `styles.css`:

```css
:root {
    --primary-700: #1e3a8a;  /* الأزرق الرئيسي */
    --primary-600: #2563eb;  /* الأزرق المتوسط */
    --primary-500: #3b82f6;  /* الأزرق الفاتح */
}
```

---

## 📱 الموقع متجاوب (Responsive)
- يعمل على جميع الأجهزة: الجوال، التابلت، الكمبيوتر
- تم اختباره على مختلف أحجام الشاشات

---

## 🔗 ربط الدومين الخاص (اختياري)

إذا اشتريت دومين مثل `abcacademia.qa`:

1. في GitHub Pages Settings، أضف الدومين في "Custom domain"
2. في إعدادات DNS للدومين، أضف:
   - Type: CNAME
   - Name: www
   - Value: [اسم-حسابك].github.io

---

## ❓ تحتاج مساعدة؟

تواصل معي وسأساعدك في أي خطوة!
